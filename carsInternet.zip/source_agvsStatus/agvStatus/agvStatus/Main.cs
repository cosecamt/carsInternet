﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;


namespace agvStatus
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            MyMethod.Main = this;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MyMethod.writeInJson();

        }

        private void btnAddA_Click(object sender, EventArgs e) {
            //在A区增加一辆小车
            Agvs agv = new Agvs("A");
            AgvCount.countA.Add(agv);
            //如果该区小车达到5辆，将此按钮禁用
            if (AgvCount.countA.Count == 5) this.btnAddA.Enabled = false;
            //如果增加一辆后，小车数量为1，则将隔壁“减少”按钮可用
            if (AgvCount.countA.Count == 1) this.btnReduceA.Enabled = true;
            //刷新页面
            MyMethod.freshListView(this);
            //写入Json文件
            MyMethod.writeInJson();
        }

        private void btnAddB_Click(object sender, EventArgs e) {
            //在B区增加一辆小车
            Agvs agv = new Agvs("B");
            AgvCount.countB.Add(agv);
            //如果该区小车达到5辆，将此按钮禁用
            if (AgvCount.countB.Count == 5) this.btnAddB.Enabled = false;
            //如果增加一辆后，小车数量为1，则将隔壁“减少”按钮可用
            if (AgvCount.countB.Count == 1) this.btnReduceB.Enabled = true;
            //刷新页面
            MyMethod.freshListView(this);
            //写入Json文件
            MyMethod.writeInJson();
        }

        private void btnReduceA_Click(object sender, EventArgs e) {
            //在A区减少一辆小车
            AgvCount.countA.RemoveAt(AgvCount.countA.Count - 1);
            //如果该区小车此时为0，将此按钮禁用
            if (AgvCount.countA.Count == 0) this.btnReduceA.Enabled = false;
            //如果减少一辆后，小车数量为4，则将隔壁“增加”按钮可用
            if (AgvCount.countA.Count == 4) this.btnAddA.Enabled = true;
            //刷新页面
            MyMethod.freshListView(this);
            //写入Json文件
            MyMethod.writeInJson();
        }

        private void btnReduceB_Click(object sender, EventArgs e) {
            //在B区减少一辆小车
            AgvCount.countB.RemoveAt(AgvCount.countB.Count - 1);
            //如果该区小车此时为0，将此按钮禁用
            if (AgvCount.countB.Count == 0) this.btnReduceB.Enabled = false;
            //如果减少一辆后，小车数量为4，则将隔壁“增加”按钮可用
            if (AgvCount.countB.Count == 4) this.btnAddB.Enabled = true;
            //刷新页面
            MyMethod.freshListView(this);
            //写入Json文件
            MyMethod.writeInJson();
        }

        private void btnStep_Click(object sender, EventArgs e) {
            MyMethod.randomData();
        }

        //此参数控制是否正在自动变换数据
        bool dataChange = false;

        private void btnStart_Click(object sender, EventArgs e) {
            if (dataChange) {
                //如果此时正处于自动变换状态
                dataChange = !dataChange;
                btnStart.Text = "开始运作";
                pictureBox1.BackColor = Color.Red;
            }else {
                //如果此时处于静止状态
                dataChange = !dataChange;
                btnStart.Text = "停止";
                pictureBox1.BackColor = Color.Green;
                Thread th = new Thread(()=> {
                    while (dataChange) {
                        MyMethod.randomData();
                        Thread.Sleep(3000);
                    }
                });
                th.Start();
            }
        }
    }
}
