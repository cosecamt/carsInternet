﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace agvStatus {
    class Agvs {
        //初始化四个属性：小车编号、当前速度、水箱温度、是否空闲。
        //小车编号：依据存在于哪个区，以及该区现存多少车辆决定；（车-A区1号）
        //当前速度：在10-40之间随机生成，单位为m/s；
        //水箱温度：在30-70之间随机生成，单位为°C；
        //是否空闲：10%概率“空闲中”，90%概率“执行任务”；
        private string agvNumber;
        private string agvSpeed;
        private string agvDegree;
        private string agvStatus;

        public Agvs(string group) {
            //传入的参数group表示是A区还是B区
            //小车编号
            agvNumber = MyMethod.createAgvNumber(group);
            //当前速度
            agvSpeed = MyMethod.randomNumber(10, 41).ToString() + "m/s";
            //水箱温度
            agvDegree = MyMethod.randomNumber(30, 71).ToString() + "°C";
            //是否空闲
            agvStatus = "空闲中";
        }
        public List<string> getAgvInfo() {
            List<string> agvInfo = new List<string>();
            agvInfo.Add(agvNumber);
            agvInfo.Add(agvSpeed);
            agvInfo.Add(agvDegree);
            agvInfo.Add(agvStatus);
            return agvInfo;
        }

        public void randomSelfInfo() {
            //当前速度
            agvSpeed = MyMethod.randomNumber(10, 41).ToString() + "m/s";
            //水箱温度
            agvDegree = MyMethod.randomNumber(30, 71).ToString() + "°C";
            //是否空闲
            if(MyMethod.randomNumber(1, 101) < 90) {
                agvStatus = "执行任务";
            }else {
                agvStatus = "空闲中";
            }            
        }
            
        }
}

