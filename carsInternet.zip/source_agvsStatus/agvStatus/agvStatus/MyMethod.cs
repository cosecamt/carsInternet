﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace agvStatus
{
    class MyMethod
    {
        //---------------------------此为通用方法---------------------------
        //生成随机数的方法
        public static int randomNumber(int a, int b) {
            
            //Random rNumber = new Random();//实例化一个随机数专对象
            Random rNumber = new Random((int)DateTime.Now.Ticks);
            int result = rNumber.Next(a, b);
            Thread.Sleep(15);
            return result;
        }

        //---------------------------此为构造中使用的方法---------------------------
        //根据传入的区号，返回当前应该生成的编号
        public static string createAgvNumber(string group) {
            int newCount = 0;
            if (group == "A") {
                newCount = AgvCount.countA.Count + 1;
            } else {
                newCount = AgvCount.countB.Count + 1;
            }
            return "小车-" + group + "区" + newCount + "号";
        }

        //---------------------------此为运行中使用的方法---------------------------
        //此方法为内部方法，会根据AgvCount里的数据对两个listview进行刷新
        public static void freshListView(Main Main) {
            //先清空
            Main.listView1.Items.Clear();
            Main.listView2.Items.Clear();
            //开始渲染A区数据
            foreach(Agvs agv in AgvCount.countA) {
                List<string> agvInfo = agv.getAgvInfo();
                ListViewItem first = new ListViewItem(agvInfo[0]);
                first.SubItems.Add(agvInfo[1]);
                first.SubItems.Add(agvInfo[2]);
                first.SubItems.Add(agvInfo[3]);
                Main.listView1.Items.Add(first);
            }
            //开始渲染B区数据
            foreach (Agvs agv in AgvCount.countB) {
                List<string> agvInfo = agv.getAgvInfo();
                ListViewItem first = new ListViewItem(agvInfo[0]);
                first.SubItems.Add(agvInfo[1]);
                first.SubItems.Add(agvInfo[2]);
                first.SubItems.Add(agvInfo[3]);
                Main.listView2.Items.Add(first);
            }
        }
        //此方法为输出json时，输入一个agv实例，传出一个数组字符串的方法
        public static string agv2list(Agvs agv) {
            List<string> agvInfo = agv.getAgvInfo();
            string agvlist = "[";
            foreach(string agvWord in agvInfo) {
                agvlist += "'";
                agvlist += agvWord;
                agvlist += "'";
                agvlist += ",";
            }
            agvlist = agvlist.Substring(0, agvlist.Length - 1);
            agvlist += "]";
            return agvlist;
        }
        //生成json
        public static void writeInJson() {
            string path = @"....../Infos.json";

            //先对A进行组合
            string listA = "[";
            if (AgvCount.countA.Count != 0) {
                foreach (Agvs agv in AgvCount.countA) {
                    listA += MyMethod.agv2list(agv);
                    listA += ",";
                }
                listA = listA.Substring(0, listA.Length - 1);
            }
            listA += "]";

            //在对B进行组合
            string listB = "[";
            if (AgvCount.countB.Count != 0) {
                foreach (Agvs agv in AgvCount.countB) {
                    listB += MyMethod.agv2list(agv);
                    listB += ",";
                }
                listB = listB.Substring(0, listB.Length - 1);
            }
            listB += "]";

            //将A和B拼在一起
            string twoList = "{";
            twoList += $"'A':{listA}";
            twoList += ",";
            twoList += $"'B':{listB}";
            twoList += "}";

            //生成文件
            JToken JToken = (JToken)JsonConvert.DeserializeObject(twoList);
            string output = Newtonsoft.Json.JsonConvert.SerializeObject(JToken, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(path, output);
        }

        //随机所有agv实例的内部数据
        public static void randomData() {
            //本质为让所有的agv实例的属性都随机变化
            //开始随机变化A区数据
            foreach (Agvs agv in AgvCount.countA) {
                agv.randomSelfInfo();
            }
            //开始随机变化B区数据
            foreach (Agvs agv in AgvCount.countB) {
                agv.randomSelfInfo();
            }
            //刷新页面
            MyMethod.freshListView(Main);
            //写入Json文件
            MyMethod.writeInJson();
        }

        //传递窗口作为参数我没招了，遭窃先这样吧
        public static Main Main;
    }
}
