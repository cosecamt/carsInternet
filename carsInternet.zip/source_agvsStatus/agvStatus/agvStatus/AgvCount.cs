﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace agvStatus
{
    class AgvCount
    {
        //此处记录小车的数量和状况，实际为一数组，数组中存在若干哈希表，每个哈希表包含四项agv的属性
        //好像暂时没什么可初始化的，就是普通的数组呗，可能在程序启动的时候要初始化一下
        //这是A区的小车
        public static List<Agvs> countA = new List<Agvs>();
        //这是B区的小车
        public static List<Agvs> countB = new List<Agvs>();
    }
}
