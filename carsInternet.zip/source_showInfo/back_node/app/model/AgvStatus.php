<?php

namespace app\model;
use think\model;

class AgvStatus extends Model{
    protected $table = 'nrt_agv_test';
}
