<?php

namespace app\controller;

use think\Request;
use app\model\AgvStatus;

class AgvStatusApi{
    //可能也就这一个接口了，把数据全拿出去
    public function getAgvStatus(){
        return AgvStatus::select();
    }
}
