<template>
  <div id="app">
    <el-card class="box-card CardBox">
      <div slot="header" class="clearfix">
        <span>A区小车状况：</span>
      </div>
      <div>
        <span class="TitleBox" style="margin: 0 60px 0 30px;">编号</span>
        <span class="TitleBox" style="margin-right: 25px">速度</span>
        <span class="TitleBox" style="margin-right: 30px">温度</span>
        <span class="TitleBox" style="margin-right: 10px">状态</span>
      </div>
      <div v-for="o in statusA" :key="o.nt_name" class="text item ListDiv">
        <span class="ListSpan">{{o.nt_name }}</span>
        <span class="ListSpan">{{o.nt_speed }}</span>
        <span class="ListSpan">{{o.nt_degree }}</span>
        <span class="ListSpan">{{o.nt_status }}</span>
      </div>
    </el-card>
    <el-card class="box-card CardBox">
      <div slot="header" class="clearfix">
        <span>B区小车状况：</span>
      </div>
      <div>
        <span class="TitleBox" style="margin: 0 60px 0 30px;">编号</span>
        <span class="TitleBox" style="margin-right: 25px">速度</span>
        <span class="TitleBox" style="margin-right: 30px">温度</span>
        <span class="TitleBox" style="margin-right: 10px">状态</span>
      </div>
      <div v-for="o in statusB" :key="o.nt_name" class="text item ListDiv">
        <span class="ListSpan">{{o.nt_name }}</span>
        <span class="ListSpan">{{o.nt_speed }}</span>
        <span class="ListSpan">{{o.nt_degree }}</span>
        <span class="ListSpan">{{o.nt_status }}</span>
      </div>
    </el-card>
  </div>
</template>

<script>

export default {
  data () {
    return {
      statusA: [],
      statusB: []
    }
  },
  methods: {
    async getAgvStatus () {
      const { data: res } = await this.$axios.post('getAgvStatus')
      this.statusA = res.slice(0, 5)
      this.statusB = res.slice(5)
      for (let i = 0; i < this.statusA.length; i++) {
        if (this.statusA[i].nt_online === 0) {
          this.statusA = this.statusA.slice(0, i)
          break
        }
      }
      for (let i = 0; i < this.statusB.length; i++) {
        if (this.statusB[i].nt_online === 0) {
          this.statusB = this.statusB.slice(0, i)
          break
        }
      }
      console.log(this.statusA)
      console.log(this.statusB)
    }
  },
  mounted () {
    this.getAgvStatus()
    window.setInterval(() => {
      setTimeout(() => {
        this.getAgvStatus()
      }, 0)
    }, 500)
  }
}
</script>

<style lang="less" scoped>
.CardBox{
  display: inline-block;
  width: 400px;
  height: 300px;
  margin-right: 50px;
}
.ListDiv{
  margin: 15px 5px;
  .ListSpan{
    margin-right: 20px;
  }
}
.TitleBox{
  font-size: 18px;
  font-weight: bold;
}
</style>
