import Vue from 'vue'
import { Button, Card, Divider } from 'element-ui'

Vue.use(Button)
Vue.use(Card)
Vue.use(Divider)
