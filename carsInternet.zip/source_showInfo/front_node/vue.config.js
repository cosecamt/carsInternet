// vue.config.js

// 跨域
module.exports = {
  // 打包地址修正
  lintOnSave: true,
  publicPath: './',
  outputDir: 'dist',
  assetsDir: 'static'
}
